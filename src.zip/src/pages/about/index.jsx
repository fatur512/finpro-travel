const AboutPage = () => {
  return (
    <div>
      <div>halaman about</div>
    </div>
  );
};

export default AboutPage;
