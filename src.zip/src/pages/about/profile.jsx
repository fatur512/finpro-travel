const ProfilePage = () => {
  return (
    <div>
      <div>Profil about</div>
    </div>
  );
};

export default ProfilePage;
