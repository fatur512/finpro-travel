import axios from "axios";
import { setCookie } from "cookies-next";
import { useRouter } from "next/router";
const Login = () => {
  const router = useRouter();
  const handleLogin = (e) => {
    e.preventDefault();
    // e.target.email.value;
    console.log(e.target.email.value);
    console.log(e.target.password.value);

    const payload = {
      email: e.target.email.value,
      password: e.target.password.value,
    };

    const url = "https://api-bootcamp.do.dibimbing.id/api/v1/login";

    const config = {
      headers: {
        "Content-Type": "application/json",
        apiKey: "w05KkI9AWhKxzvPFtXotUva-",
      },
    };
    axios
      .post(url, payload, config)
      .then((res) => {
        setCookie("token", res.data.token);
        // alert(res.data.message);
        router.push("/dashboard");
      })
      .catch((err) => {
        alert(err.response.data.message);
      });
  };
  return (
    <form onSubmit={handleLogin} className="flex flex-col items-center justify-center w-screen h-screen gap-3">
      <h1>login</h1>
      <label htmlFor="email">
        email
        <input id="email" type="text" name="email" className="ml-2 border-2" />
      </label>
      <label htmlFor="password">
        password
        <input id="password" type="password" name="password" className="ml-2 border-2" />
      </label>
      <button type="submit" className="px-2 py-1 text-white bg-blue-500 rounded-md border-1">
        Login
      </button>
    </form>
  );
};

export default Login;
