import { deleteCookie, getCookie } from "cookies-next";
import { useEffect } from "react";
import { useRouter } from "next/router";
import axios from "axios";

export async function getServerSideProps({ req, res }) {
  const token = getCookie("token", { req, res });
  if (!token) {
    return {
      redirect: {
        destination: "/auth/login",
        permanent: false,
      },
    };
  }
  return {
    props: {},
  };
}
const Dashboard = () => {
  //   const token = getCookie("token");
  const router = useRouter();
  //   useEffect(() => {
  //     if (!token) {
  //       router.push("/auth/login");
  //     }
  //   }, [token]);

  const logout = () => {
    deleteCookie("token");
    router.push("/auth/login");
  };

  return (
    <div>
      <h1>Dashboard</h1>
      <button className="px-1 text-white bg-blue-400" onClick={logout}>
        Logout
      </button>
    </div>
  );
};

export default Dashboard;
